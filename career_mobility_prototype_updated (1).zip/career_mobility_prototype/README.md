# Your Career, Mapped — VS Code prototype

A dependency-free prototype built from the supplied **Interactive Career Mobility Map** and **Definition of Skills** documents.

## What is included

- **Explore a move**
  - choose a current function and a target function
  - see transferable capability and specialist knowledge gaps
  - classify the move as close / adjacent / stretch
  - if no direct route exists, calculate a shortest multi-step route
  - keep full current/target skill profiles inside an optional disclosure

- **Interactive movement map**
  - all mapped direct career movements from the source document
  - click a function to highlight its possible destinations
  - filter close / adjacent / stretch routes
  - click a route to see what transfers and what the knowledge gap is
  - highlight the route generated in the Current → Dream feature

- **How to get there**
  - interactive Punting → Walking → Cycling → Train development pathway
  - Explore & discover → Build capability → Stretch & broaden → Experience another role
  - practical development activities under each mode
  - suggested starting mode based on the selected career move
  - simple click-to-build development route

- **Skills Bank**
  - simplified taxonomy: Transferable skills / Applied by function / Specialist knowledge
  - department-wide capabilities appear as a "Core across CUDAR" badge rather than a separate taxonomy
  - search and function filters

- **Career journeys in practice**
  - five anonymised movement journeys
  - expandable stories
  - what carried across
  - what was built
  - why cross-functional movement mattered

## Run it in VS Code

There is no build step and no package install.

### Easiest option: Live Server
1. Open this folder in VS Code.
2. Install the **Live Server** extension if you do not already have it.
3. Right-click `index.html`.
4. Choose **Open with Live Server**.

### Or use Python
From the VS Code terminal:

```bash
python -m http.server 8000
```

Then open:

```text
http://localhost:8000
```

## Files

- `index.html` — page structure
- `styles.css` — visual design and responsive layout
- `data.js` — source-derived functions, skills, movement edges and example journeys
- `app.js` — interactions, route-finding, map logic and filtering

## Editing the content

### Add or change a function
Edit the `FUNCTIONS` object in `data.js`.

### Add a direct movement
Add an object to `EDGES` in `data.js`:

```js
{
  source: "Current function",
  target: "Destination function",
  sourceDestinationLabel: "Destination label used in source",
  type: "close", // close | adjacent | stretch
  transfers: ["Skill one", "Skill two"],
  gap: ["Knowledge gap one", "Knowledge gap two"]
}
```

### Change the five example journeys
Edit `JOURNEYS` in `data.js`.

## Design note

The prototype intentionally avoids scoring employees or presenting a move as “you are X% qualified.” The source framework is more developmental: it distinguishes transferable capability, adjacent/applied experience and specialist knowledge, then shows how an employee could build the bridge through concrete development experiences. The transport modes represent the intensity/distance of movement, not employee seniority.
